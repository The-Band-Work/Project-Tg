
07/07.2021

README-tgondii-bradyzoite autophagy__.txt
#file added to document many embedded links lost in PDF #version...perhaps not needed?

Links in U Mich papers relating to T gondii bradyzoite autophagy

Toxoplasma TgATG9 is critical for autophagy and long-term persistence in tissue cysts
https://elifesciences.org/articles/59384#sa2
